from django.apps import AppConfig


class FinanceConfig(AppConfig):
    name = 'finance'
